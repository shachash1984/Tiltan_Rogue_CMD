#include<iostream>
#include<string>
#include"GameManager.h"
#include"Level.h"

using namespace std;


int main() {

	GameManager::Init();


	//END
	return 0;
}